<?php

$images =[];


// Assign JSON encoded string to a PHP variable
$json = file_get_contents("data/projects.json");
// Decode JSON data into PHP associative array format
$decode = json_decode($json, true);

if(!is_array($decode)){
    die("ERROR: Input is not an array");
}

/*
Loop through array, if value is itself an array recursively call the
function else add the value found to the output items array,
and increment counter by 1 for each value found
*/
foreach($decode as $key=>$value)
{
    if ($key == "data")
    {
        foreach($value as $ImageInfo)
        {
            $imagePath = "https://demo.innosabi.com/api/v4/media/";
            $imagePath = $imagePath .$ImageInfo['image'];
            $imagePath = $imagePath ."/thumbnail";
            array_push($images, array($imagePath, $ImageInfo['name'], $ImageInfo['description']));
        }
    }
}

//foreach($images as $key=>$value)
//{
    //echo  $images[$key][0];
    //echo "<br>";
//}

?>