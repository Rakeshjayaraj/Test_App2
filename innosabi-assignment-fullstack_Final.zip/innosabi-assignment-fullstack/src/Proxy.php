<?php
require __DIR__ . '/../vendor/autoload.php';

use Curl\CURL;

$curl = new Curl();
$curl->setBasicAuthentication("api@innosabi.com", "0thRuch0");
$curl->setUserAgent('MyUserAgent/0.0.1 (+https://demo.innosabi.com/api/v2/project/filter)');
$curl->setReferrer('https://demo.staging.innosabi.com/login');
$curl->setHeader('X-Requested-With', 'XMLHttpRequest');
$curl->setCookie('Rakesh', 'Rakesh');

$curl->setHeader('Content-Type', 'application/json');
$curl->get('https://demo.innosabi.com/api/v2/project/filter');

if ($curl->error) {
    echo 'Error: ' . $curl->errorCode . ': ' . $curl->errorMessage . "\n";
} else {
    echo 'Response:' . "\n";
    var_dump($curl->response);
}

var_dump($curl->requestHeaders);

var_dump($curl->responseHeaders);


?> -->
 