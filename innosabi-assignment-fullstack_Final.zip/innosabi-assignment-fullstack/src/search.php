<?php
$ch = curl_init("http://127.0.0.1:9999/highlight.html");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$text = curl_exec($ch);
$test = strpos($text, "<!-- BEGIN TEST CODE -->");
if ($test==false)
{
    echo "no";
}
else
{
    echo "yes";
}
?>